<?php 
//Authorize.Net Credentials Configuration
define("AUTHORIZE_API_LOGIN_ID", "3tTgS35L");
define("AUTHORIZE_TRANSACTION_KEY", "6A6KYqEpJ736h3RS");
// define("AUTHORIZE_ENV", "SANDBOX");
define("AUTHORIZE_ENV", "PRODUCTION");

// Database Credentials Configuration 
define('DB_HOST', 'localhost');
define('DB_NAME', 'authorize_payment');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
?>